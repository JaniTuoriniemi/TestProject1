//using CalculatorSelenium.Specs.Drivers;
//using CalculatorSelenium.Specs.PageObjects;
//using System;
//using System.Security.Policy;
//using TechTalk.SpecFlow;
//using static System.Net.WebRequestMethods;

//namespace SpecFlowProject1.StepDefinitions
//{
  //  [Binding]
    //public class TestStepDefinitions
   // {
     //   private readonly CalculatorPageObject _calculatorPageObject;

       // public TestStepDefinitions(BrowserDriver browserDriver)
        //{
          //  _calculatorPageObject = new CalculatorPageObject(browserDriver.Current);
        //}
       //[When()]
        //public void WhenTheLinkIsClicked()
        //{
          //  _calculatorPageObject.Clicklogin();

        //}

        //[Then(@"the browser is directed to https://reink\.se/auth/login")]
        //public void ThenTheBrowserIsDirectedToHttpsReink_SeAuthLogin()
        //{  _calculatorPageObject.Clicklogin();
          // string   url= "https://reink.se/auth/login";
            //string actualResult = _calculatorPageObject.CurrentURL();
            //actualResult.Should().Be(url.ToString());
      // }
    
//}
    
//}
